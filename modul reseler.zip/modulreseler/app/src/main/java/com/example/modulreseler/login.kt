package com.example.modulreseler
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class login {



    class LoginActivity : AppCompatActivity() {

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_login)

            val username = findViewById<EditText>(R.id.etUsername)
            val password = findViewById<EditText>(R.id.etPassword)
            val btnLogin = findViewById<Button>(R.id.btnLogin)

            btnLogin.setOnClickListener {
                val user = username.text.toString()
                val pass = password.text.toString()

                if (user == "admin" && pass == "123") {
                    Toast.makeText(this, "Login Berhasil", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Username atau Password salah", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

}